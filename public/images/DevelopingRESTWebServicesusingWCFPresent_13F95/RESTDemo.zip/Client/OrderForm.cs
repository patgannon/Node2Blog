﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Windows.Forms;

using Contracts.ServiceInterfaces;
using Contracts.Messages;
using Library;

namespace Client
{
    public partial class OrderForm : Form
    {
        public OrderForm()
        {
            InitializeComponent();
        }

        private void _orderButton_Click(object sender, EventArgs e)
        {
            WebHttpBinding binding = new WebHttpBinding();
            WebChannelFactory<IOrderService> channelFactory = new WebChannelFactory<IOrderService>(binding, new Uri("http://localhost:8080"));
            IOrderService serviceProxy = channelFactory.CreateChannel();

            try
            {
                using ((IDisposable)serviceProxy)
                {
                    if (_itemTypeDropDown.SelectedItem == null)
                    {
                        MessageBox.Show("Must select an item type from the drop-down");
                        return;
                    }

                    int quantity;

                    if (!int.TryParse(_quantityText.Text, out quantity))
                    {
                        MessageBox.Show("Quantity must be an integer");
                        return;
                    }

                    Order order = new Order { Type = (OrderType)Enum.Parse(typeof(OrderType), _itemTypeDropDown.SelectedItem.ToString()), Quantity = quantity };

                    order = serviceProxy.PlaceOrder(order);

                    MessageBox.Show("Order number is: " + order.OrderNumber);
                }
            }
            catch (EndpointNotFoundException ex)
            {
                WebException webException = ex.InnerException as WebException;

                if (webException != null)
                {
                    if (webException.Message == "Unable to connect to the remote server")
                        MessageBox.Show("Unable to connect to web service");
                    else
                        MessageBox.Show("An error occurred:" + Environment.NewLine + ex);
                }
                else
                    throw ex;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred:" + Environment.NewLine + ex);
            }
        }

        private void _viewButton_Click(object sender, EventArgs e)
        {
            WebHttpBinding binding = new WebHttpBinding();
            WebChannelFactory<IOrderService> channelFactory = new WebChannelFactory<IOrderService>(binding, new Uri("http://localhost:8080"));
            IOrderService serviceProxy = channelFactory.CreateChannel();
            int orderNumber = -1;

            try
            {
                using ((IDisposable)serviceProxy)
                {
                    if (!int.TryParse(_orderNumberText.Text, out orderNumber))
                    {
                        MessageBox.Show("Order number be an integer");
                        return;
                    }

                    Order order = serviceProxy.GetOrder(orderNumber.ToString());

                    _orderDisplayText.Text += OrderFormatter.FormatOrder(order) + Environment.NewLine;
                }
            }
            catch (EndpointNotFoundException ex)
            {
                WebException webException = ex.InnerException as WebException;

                if (webException != null)
                {
                    if (webException.Message == "The remote server returned an error: (404) Not Found.")
                        MessageBox.Show("Order not found: " + orderNumber);
                    else
                    {
                        if (webException.Message == "Unable to connect to the remote server")
                            MessageBox.Show("Unable to connect to web service");
                        else
                            MessageBox.Show("An error occurred:" + Environment.NewLine + ex);
                    }
                }
                else
                    MessageBox.Show("An error occurred:" + Environment.NewLine + ex);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred:" + Environment.NewLine + ex);
            }
        }
    }
}
