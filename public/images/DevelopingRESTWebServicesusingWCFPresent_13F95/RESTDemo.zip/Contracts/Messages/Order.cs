﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Security;

namespace Contracts.Messages
{
    [DataContract]
    public class Order
    {
        [DataMember]
        public int OrderNumber;
        [DataMember]
        public OrderType Type;
        [DataMember]
        public int Quantity;
    }
}
