﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebService
{
    public static class ServiceOutput
    {
        public static event EventHandler<ServiceOutputEventArgs> OutputSent;

        public static void FireOutputSent(object sender, string output)
        {
            if (OutputSent != null)
                OutputSent.Invoke(sender, new ServiceOutputEventArgs { Message = output });
        }
    }

    public class ServiceOutputEventArgs : EventArgs
    {
        public string Message { get; set; }
    }
}
