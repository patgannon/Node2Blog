﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

using Contracts.Messages;
using Contracts.ServiceInterfaces;
using Library;

namespace WebService
{
    // NOTE: If you change the class name "Service1" here, you must also update the reference to "Service1" in Web.config and in the associated .svc file.
    public class OrderService : IOrderService
    {
        private static List<Order> _orders = new List<Order>();

        public Order GetOrder(string orderNumberStr)
        {
            int orderNumber;

            if (!int.TryParse(orderNumberStr, out orderNumber))
            {
                WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.BadRequest; //400
                return null;
            }

            Order order = _orders.Where(o => o.OrderNumber == orderNumber).SingleOrDefault();

            if (order == null)
            {
                WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.NotFound; //404
                return null;
            }

            return order;
        }

        public Order PlaceOrder(Order order)
        {
            _orders.Add(order);

            order.OrderNumber = _orders.Count;
            ServiceOutput.FireOutputSent(this, OrderFormatter.FormatOrder(order) + Environment.NewLine);

            return order;
        }

        public void DeleteOrder(string orderNumberStr)
        {
            Order order = GetOrder(orderNumberStr);

            if (order == null)
                return; //HTTP code set in GetOrder
            else
                _orders.Remove(order);
        }

        public void UpdateOrder(string orderNumberStr, Order newOrder)
        {
            Order oldOrder = GetOrder(orderNumberStr);

            if (oldOrder == null)
                return; //HTTP code set in GetOrder
            else
            {
                _orders.Remove(oldOrder);
                _orders.Add(newOrder);
            }
        }
    }
}
