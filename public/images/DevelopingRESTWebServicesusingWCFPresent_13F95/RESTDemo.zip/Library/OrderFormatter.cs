﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Contracts.Messages;

namespace Library
{
    public static class OrderFormatter
    {
        public static string FormatOrder(Order order)
        {
            return string.Format("Order {0}- Type: {1}, Quantity: {2}", order.OrderNumber, order.Type, order.Quantity);
        }
    }
}
