﻿namespace Client
{
    partial class OrderForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._itemTypeLabel = new System.Windows.Forms.Label();
            this._itemTypeDropDown = new System.Windows.Forms.ComboBox();
            this._quantityLabel = new System.Windows.Forms.Label();
            this._quantityText = new System.Windows.Forms.TextBox();
            this._orderButton = new System.Windows.Forms.Button();
            this._orderNumberLabel = new System.Windows.Forms.Label();
            this._orderNumberText = new System.Windows.Forms.TextBox();
            this._viewButton = new System.Windows.Forms.Button();
            this._orderDisplayText = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // _itemTypeLabel
            // 
            this._itemTypeLabel.AutoSize = true;
            this._itemTypeLabel.Location = new System.Drawing.Point(13, 13);
            this._itemTypeLabel.Name = "_itemTypeLabel";
            this._itemTypeLabel.Size = new System.Drawing.Size(57, 13);
            this._itemTypeLabel.TabIndex = 0;
            this._itemTypeLabel.Text = "Item Type:";
            // 
            // _itemTypeDropDown
            // 
            this._itemTypeDropDown.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this._itemTypeDropDown.FormattingEnabled = true;
            this._itemTypeDropDown.Items.AddRange(new object[] {
            "Book",
            "CD",
            "DVD"});
            this._itemTypeDropDown.Location = new System.Drawing.Point(77, 5);
            this._itemTypeDropDown.Name = "_itemTypeDropDown";
            this._itemTypeDropDown.Size = new System.Drawing.Size(195, 21);
            this._itemTypeDropDown.TabIndex = 1;
            // 
            // _quantityLabel
            // 
            this._quantityLabel.AutoSize = true;
            this._quantityLabel.Location = new System.Drawing.Point(13, 30);
            this._quantityLabel.Name = "_quantityLabel";
            this._quantityLabel.Size = new System.Drawing.Size(49, 13);
            this._quantityLabel.TabIndex = 2;
            this._quantityLabel.Text = "Quantity:";
            // 
            // _quantityText
            // 
            this._quantityText.Location = new System.Drawing.Point(77, 30);
            this._quantityText.Name = "_quantityText";
            this._quantityText.Size = new System.Drawing.Size(61, 20);
            this._quantityText.TabIndex = 3;
            // 
            // _orderButton
            // 
            this._orderButton.Location = new System.Drawing.Point(77, 57);
            this._orderButton.Name = "_orderButton";
            this._orderButton.Size = new System.Drawing.Size(75, 23);
            this._orderButton.TabIndex = 4;
            this._orderButton.Text = "Place Order";
            this._orderButton.UseVisualStyleBackColor = true;
            this._orderButton.Click += new System.EventHandler(this._orderButton_Click);
            // 
            // _orderNumberLabel
            // 
            this._orderNumberLabel.AutoSize = true;
            this._orderNumberLabel.Location = new System.Drawing.Point(12, 116);
            this._orderNumberLabel.Name = "_orderNumberLabel";
            this._orderNumberLabel.Size = new System.Drawing.Size(73, 13);
            this._orderNumberLabel.TabIndex = 5;
            this._orderNumberLabel.Text = "Order Number";
            // 
            // _orderNumberText
            // 
            this._orderNumberText.Location = new System.Drawing.Point(91, 116);
            this._orderNumberText.Name = "_orderNumberText";
            this._orderNumberText.Size = new System.Drawing.Size(100, 20);
            this._orderNumberText.TabIndex = 6;
            // 
            // _viewButton
            // 
            this._viewButton.Location = new System.Drawing.Point(197, 116);
            this._viewButton.Name = "_viewButton";
            this._viewButton.Size = new System.Drawing.Size(75, 23);
            this._viewButton.TabIndex = 7;
            this._viewButton.Text = "View Order";
            this._viewButton.UseVisualStyleBackColor = true;
            this._viewButton.Click += new System.EventHandler(this._viewButton_Click);
            // 
            // _orderDisplayText
            // 
            this._orderDisplayText.Location = new System.Drawing.Point(16, 159);
            this._orderDisplayText.Multiline = true;
            this._orderDisplayText.Name = "_orderDisplayText";
            this._orderDisplayText.ReadOnly = true;
            this._orderDisplayText.Size = new System.Drawing.Size(256, 144);
            this._orderDisplayText.TabIndex = 8;
            // 
            // OrderForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 315);
            this.Controls.Add(this._orderDisplayText);
            this.Controls.Add(this._viewButton);
            this.Controls.Add(this._orderNumberText);
            this.Controls.Add(this._orderNumberLabel);
            this.Controls.Add(this._orderButton);
            this.Controls.Add(this._quantityText);
            this.Controls.Add(this._quantityLabel);
            this.Controls.Add(this._itemTypeDropDown);
            this.Controls.Add(this._itemTypeLabel);
            this.Name = "OrderForm";
            this.Text = "Order Form";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label _itemTypeLabel;
        private System.Windows.Forms.ComboBox _itemTypeDropDown;
        private System.Windows.Forms.Label _quantityLabel;
        private System.Windows.Forms.TextBox _quantityText;
        private System.Windows.Forms.Button _orderButton;
        private System.Windows.Forms.Label _orderNumberLabel;
        private System.Windows.Forms.TextBox _orderNumberText;
        private System.Windows.Forms.Button _viewButton;
        private System.Windows.Forms.TextBox _orderDisplayText;
    }
}

