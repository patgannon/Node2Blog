﻿namespace ServiceHost
{
    partial class ServiceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._startButton = new System.Windows.Forms.Button();
            this._outputText = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // _startButton
            // 
            this._startButton.Location = new System.Drawing.Point(87, 12);
            this._startButton.Name = "_startButton";
            this._startButton.Size = new System.Drawing.Size(113, 23);
            this._startButton.TabIndex = 0;
            this._startButton.Text = "Start Service";
            this._startButton.UseVisualStyleBackColor = true;
            this._startButton.Click += new System.EventHandler(this._startButton_Click);
            // 
            // _outputText
            // 
            this._outputText.Location = new System.Drawing.Point(13, 47);
            this._outputText.Multiline = true;
            this._outputText.Name = "_outputText";
            this._outputText.ReadOnly = true;
            this._outputText.Size = new System.Drawing.Size(259, 205);
            this._outputText.TabIndex = 1;
            // 
            // ServiceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 264);
            this.Controls.Add(this._outputText);
            this.Controls.Add(this._startButton);
            this.Name = "ServiceForm";
            this.Text = "Orders";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button _startButton;
        private System.Windows.Forms.TextBox _outputText;
    }
}

