﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.ServiceModel;
using System.ServiceModel.Description;
using System.ServiceModel.Web;
using System.Text;
using System.Windows.Forms;

using Contracts.ServiceInterfaces;
using WebService;

namespace ServiceHost
{
    public partial class ServiceForm : Form
    {
        private WebServiceHost _host = null;

        public ServiceForm()
        {
            InitializeComponent();
            ServiceOutput.OutputSent += new EventHandler<ServiceOutputEventArgs>(OnServiceOutput);
        }

        private void _startButton_Click(object sender, EventArgs e)
        {
            StartService();
            _outputText.Text += "Service started." + Environment.NewLine;
            _startButton.Enabled = false;
        }

        private void StartService()
        {
            _host = new WebServiceHost(typeof(OrderService));
            WebHttpBinding binding = new WebHttpBinding();
            ServiceEndpoint endpoint = _host.AddServiceEndpoint(typeof(IOrderService), binding, "http://localhost:8080");
            endpoint.Behaviors.Add(new WebHttpBehavior());
            _host.Open();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
 	        base.OnFormClosing(e);

            if (_host != null)
                _host.Close();
        }

        private void OnServiceOutput(object o, ServiceOutputEventArgs args)
        {
            _outputText.Text += args.Message + Environment.NewLine;
        }
    }
}
