﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

using Contracts.Messages;

namespace Contracts.ServiceInterfaces
{
    // NOTE: If you change the interface name "IService1" here, you must also update the reference to "IService1" in Web.config.
    [ServiceContract]
    public interface IOrderJsonService
    {
        [OperationContract, WebGet(UriTemplate = "/Order/{orderNumberStr}", 
            BodyStyle=WebMessageBodyStyle.Wrapped, ResponseFormat=WebMessageFormat.Json)]
        Order GetOrder(string orderNumberStr);

        [OperationContract, WebInvoke(UriTemplate = "/Order", Method = "POST",
            BodyStyle=WebMessageBodyStyle.Wrapped, ResponseFormat=WebMessageFormat.Json)]
        Order PlaceOrder(Order order);

        [OperationContract, WebInvoke(UriTemplate = "/Order/{orderNumberStr}", Method = "PUT",
            BodyStyle=WebMessageBodyStyle.Wrapped, ResponseFormat=WebMessageFormat.Json)]
        void UpdateOrder(string orderNumberStr, Order newOrder);

        [OperationContract, WebInvoke(UriTemplate = "/Order/{orderNumberStr}", Method = "DELETE",
            BodyStyle=WebMessageBodyStyle.Wrapped, ResponseFormat=WebMessageFormat.Json)]
        void DeleteOrder(string orderNumberStr);
    }
}
