﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Contracts.Messages
{
    [Serializable]
    public enum OrderType
    {
        None = 0,
        Book = 1,
        CD = 2,
        DVD = 3
    }
}
