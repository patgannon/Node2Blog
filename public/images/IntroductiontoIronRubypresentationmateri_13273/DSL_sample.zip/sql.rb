require 'MongoDB.Driver.dll'
include MongoDB::Driver

class Sql
  def self.query(database, &block)
    sql = Sql.new
    sql.instance_eval(&block)
    sql.execute(database)
  end
  def select(*selected_fields)
    @selected_fields = selected_fields
  end
  def from(collection)
    @collection = collection.to_s
  end
  def where(where)
    @where = where
  end
  def execute(database)
    db = Mongo.new
    db.Connect
    
    begin
      cursor = db[database][@collection].Find(@where)
  
      for doc in cursor.Documents
        puts "result was: #{doc}"
      end
    ensure
      db.Disconnect
    end
  end
end
    