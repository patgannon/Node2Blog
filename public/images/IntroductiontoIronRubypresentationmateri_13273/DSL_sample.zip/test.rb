require 'sql'

Sql.query "test" do
  select :field1, :field2
  from :test_collection
  where "this.othercol == 'val'"
end
