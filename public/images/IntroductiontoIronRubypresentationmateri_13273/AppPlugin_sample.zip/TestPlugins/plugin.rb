class TestPlugin
  def sayhello(name)
    puts "hello, #{name}"
    
    return "success!"
  end
end
