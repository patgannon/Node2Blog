﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Scripting.Hosting;

namespace TestPlugins
{
    public static class Class1
    {
        public static void Main(string[] args)
        {
            ScriptRuntime runtime = ScriptRuntime.CreateFromConfiguration();
            runtime.ExecuteFile("plugin.rb");
            var engine = runtime.GetEngine("Ruby");
            var code = String.Format("TestPlugin.new.sayhello '{0}'", "Pat");
            var output = engine.CreateScriptSourceFromString(code).Execute();

            Console.WriteLine("Ruby plug-in returned: " + output);
        }
    }
}
